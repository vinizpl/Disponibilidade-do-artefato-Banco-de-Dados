-- Ingestao reproducivel PAD-UFES-20 metadata.csv (26 campos, texto de origem)
-- CSV verificado pelo SHA-256 no script Python ANTES da execucao.
-- Executar com psql -X -v ON_ERROR_STOP=1 -f 02_ingestao_pad_ufes20.sql
-- Requer schema derm_v2 recem-criado pelo arquivo 01 (nao e idempotente).
BEGIN;
CREATE TEMP TABLE pad_csv (
    patient_id text,
    lesion_id text,
    smoke text,
    drink text,
    background_father text,
    background_mother text,
    age text,
    pesticide text,
    gender text,
    skin_cancer_history text,
    cancer_history text,
    has_piped_water text,
    has_sewage_system text,
    fitspatrick text,
    region text,
    diameter_1 text,
    diameter_2 text,
    diagnostic text,
    itch text,
    grew text,
    hurt text,
    changed text,
    bleed text,
    elevation text,
    img_id text,
    biopsed text
) ON COMMIT DROP;
\copy pad_csv FROM '/tmp/pad_ufes20_original.csv' WITH (FORMAT csv, HEADER true, NULL '\N')

DO $$
DECLARE
    total_linhas bigint;
    valores_nao_mapeados bigint;
    imgs_distintas bigint;
BEGIN
    SELECT count(*), count(DISTINCT img_id)
      INTO total_linhas, imgs_distintas FROM pad_csv;
    IF total_linhas <> 2298 OR imgs_distintas <> 2298 THEN
      RAISE EXCEPTION 'CSV inesperado: linhas=%, img_id distintos=%', total_linhas, imgs_distintas;
    END IF;
    SELECT count(*) INTO valores_nao_mapeados FROM pad_csv
     WHERE fitspatrick NOT IN ('', '1.0', '2.0', '3.0', '4.0', '5.0', '6.0');
    IF valores_nao_mapeados > 0 THEN
      RAISE EXCEPTION 'Fitzpatrick com valores nao classificados: %', valores_nao_mapeados;
    END IF;
    IF EXISTS (SELECT 1 FROM pad_csv WHERE patient_id = '' OR lesion_id = '' OR img_id = '') THEN
      RAISE EXCEPTION 'IDs obrigatorios vazios no CSV';
    END IF;
END $$;

INSERT INTO derm_v2.fonte(nome, versao)
VALUES ('PAD-UFES-20 metadata.csv', 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527');

-- Registrar todas as linhas como JSONB, conservando os textos dos 26 campos.
-- Nao equivale a conservar os bytes ou a ordem dos campos CSV: o hash protege esse arquivo.
INSERT INTO derm_v2.staging_registro (
    fonte_id, identificador_registro_origem, colecao_ou_arquivo_origem, registro_jsonb
)
SELECT f.fonte_id, raw.img_id, 'metadata.csv', to_jsonb(raw)
FROM pad_csv AS raw
CROSS JOIN derm_v2.fonte f
WHERE f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527';

INSERT INTO derm_v2.paciente(fonte_id, identificador_origem)
SELECT DISTINCT f.fonte_id, raw.patient_id
FROM pad_csv raw
CROSS JOIN derm_v2.fonte f
WHERE f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527';

-- A chave composta impede confundir mesmo lesion_id de dois pacientes.
INSERT INTO derm_v2.lesao (
    fonte_id, paciente_id, evidencia_vinculo_paciente, identificador_origem
)
SELECT DISTINCT f.fonte_id, p.paciente_id,
       'metadata.csv: colunas patient_id e lesion_id (mesma linha)',
       raw.lesion_id
FROM pad_csv AS raw
JOIN derm_v2.fonte f ON f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527'
JOIN derm_v2.paciente p ON p.fonte_id = f.fonte_id
  AND p.identificador_origem = raw.patient_id;

INSERT INTO derm_v2.imagem (
    fonte_id, lesao_id, evidencia_vinculo_lesao,
    identificador_origem, staging_id
)
SELECT f.fonte_id, l.lesao_id,
       'metadata.csv: colunas patient_id, lesion_id e img_id (mesma linha)',
       raw.img_id, s.staging_id
FROM pad_csv raw
JOIN derm_v2.fonte f ON f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527'
JOIN derm_v2.paciente p ON p.fonte_id = f.fonte_id
  AND p.identificador_origem = raw.patient_id
JOIN derm_v2.lesao l ON l.fonte_id = f.fonte_id
  AND l.paciente_id = p.paciente_id
  AND l.identificador_origem = raw.lesion_id
JOIN derm_v2.staging_registro s ON s.fonte_id = f.fonte_id
  AND s.identificador_registro_origem = raw.img_id;

-- Apenas atributos presentes/ausentes de forma verificavel no cabecalho.
-- Como a linha do CSV corresponde a img_id, registramos fitspatrick por linha/imagem;
-- nao inferimos atribuicao clinica, autodeclaracao nem valor unico por paciente.
INSERT INTO derm_v2.catalogo_fonte_atributo(
    fonte_id, atributo, unidade, campo_existe, nome_campo_origem, tipo_dado_original,
    evidencia_documental
)
SELECT f.fonte_id, x.atributo::derm_v2.tipo_atributo,
       'imagem'::derm_v2.unidade_observacao, x.existe,
       x.coluna, CASE WHEN x.existe THEN 'texto do CSV' ELSE NULL END,
       x.evidencia
FROM derm_v2.fonte f
CROSS JOIN (VALUES
    ('fitzpatrick', true, 'fitspatrick', 'metadata.csv: coluna fitspatrick; unidade da linha img_id'),
    ('raca_cor_ibge', false, NULL, 'metadata.csv: cabecalho sem campo de autodeclaracao IBGE'),
    ('ita', false, NULL, 'metadata.csv: cabecalho sem ITA'),
    ('monk', false, NULL, 'metadata.csv: cabecalho sem Monk')
) AS x(atributo, existe, coluna, evidencia)
WHERE f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527';

-- Regra de normalizacao explicita e versionada, inclusive para vazio.
INSERT INTO derm_v2.mapeamento_valor (
    fonte_id, atributo, unidade, versao_mapeamento,
    valor_origem, estado_destino, valor_categoria_destino, regra_documentada
)
SELECT f.fonte_id,
       'fitzpatrick'::derm_v2.tipo_atributo,
       'imagem'::derm_v2.unidade_observacao, 1,
       x.original, x.estado::derm_v2.estado_observacao,
       x.categoria,
       'Regra da pesquisa v1: ' || x.justificativa
FROM derm_v2.fonte f
CROSS JOIN (VALUES
    ('', 'ausente', NULL, 'string vazia no CSV; nao equivale a UNK'),
    ('1.0', 'preenchido', 'I', 'codigo numerico 1.0 para fototipo I'),
    ('2.0', 'preenchido', 'II', 'codigo numerico 2.0 para fototipo II'),
    ('3.0', 'preenchido', 'III', 'codigo numerico 3.0 para fototipo III'),
    ('4.0', 'preenchido', 'IV', 'codigo numerico 4.0 para fototipo IV'),
    ('5.0', 'preenchido', 'V', 'codigo numerico 5.0 para fototipo V'),
    ('6.0', 'preenchido', 'VI', 'codigo numerico 6.0 para fototipo VI')
) AS x(original, estado, categoria, justificativa)
WHERE f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527';

-- Um evento de observacao por registro de imagem, inclusive se vazio.
INSERT INTO derm_v2.observacao(
    fonte_id, atributo, unidade, imagem_id, estado,
    valor_categoria, valor_origem, mapeamento_id, metodo, situacao_atribuidor, staging_id
)
SELECT f.fonte_id,
       'fitzpatrick'::derm_v2.tipo_atributo,
       'imagem'::derm_v2.unidade_observacao,
       i.imagem_id, mv.estado_destino,
       mv.valor_categoria_destino, raw.fitspatrick,
       mv.mapeamento_id,
       'nao_documentado'::derm_v2.metodo_atribuicao,
       'nao_documentado'::derm_v2.estado_atribuidor,
       i.staging_id
FROM pad_csv raw
JOIN derm_v2.fonte f ON f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527'
JOIN derm_v2.imagem i ON i.fonte_id = f.fonte_id
  AND i.identificador_origem = raw.img_id
JOIN derm_v2.mapeamento_valor mv ON mv.fonte_id = f.fonte_id
  AND mv.atributo = 'fitzpatrick' AND mv.unidade = 'imagem'
  AND mv.versao_mapeamento = 1 AND mv.valor_origem = raw.fitspatrick;

-- Verificacoes SQL cruzadas com contagem de origem na mesma transacao.
DO $$
DECLARE
  v_fonte bigint;
  n_raw bigint; n_stg bigint; n_p bigint; n_l bigint; n_i bigint; n_o bigint;
  v_raw_p bigint; v_raw_l bigint; v_raw_i bigint; v_raw_missing bigint;
  v_missing bigint; v_collisions bigint; v_raw_collisions bigint;
BEGIN
  SELECT fonte_id INTO STRICT v_fonte FROM derm_v2.fonte
  WHERE nome = 'PAD-UFES-20 metadata.csv'
    AND versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527';
  SELECT count(*), count(DISTINCT patient_id),
         count(DISTINCT (patient_id, lesion_id)), count(DISTINCT img_id),
         count(*) FILTER (WHERE fitspatrick = '')
    INTO n_raw, v_raw_p, v_raw_l, v_raw_i, v_raw_missing
  FROM pad_csv;
  SELECT count(*) INTO n_stg FROM derm_v2.staging_registro WHERE fonte_id=v_fonte;
  SELECT count(*) INTO n_p FROM derm_v2.paciente WHERE fonte_id=v_fonte;
  SELECT count(*) INTO n_l FROM derm_v2.lesao WHERE fonte_id=v_fonte;
  SELECT count(*) INTO n_i FROM derm_v2.imagem WHERE fonte_id=v_fonte;
  SELECT count(*) INTO n_o FROM derm_v2.observacao WHERE fonte_id=v_fonte;
  SELECT count(*) INTO v_missing FROM derm_v2.observacao
  WHERE fonte_id=v_fonte AND estado='ausente' AND atributo='fitzpatrick';
  SELECT count(*) INTO v_collisions FROM (
    SELECT identificador_origem FROM derm_v2.lesao WHERE fonte_id=v_fonte
    GROUP BY identificador_origem HAVING count(DISTINCT paciente_id)>1
  ) q;
  SELECT count(*) INTO v_raw_collisions FROM (
    SELECT lesion_id FROM pad_csv GROUP BY lesion_id
    HAVING count(DISTINCT patient_id)>1
  ) q;
  IF n_stg<>n_raw OR n_p<>v_raw_p OR n_l<>v_raw_l OR n_i<>v_raw_i
     OR n_o<>n_raw OR v_missing<>v_raw_missing OR v_collisions<>v_raw_collisions THEN
      RAISE EXCEPTION 'Contagens nao coincidem: staging %/% paciente %/% lesao %/% imagem %/% obs %/% ausencia %/% colisoes %/%',
       n_stg,n_raw,n_p,v_raw_p,n_l,v_raw_l,n_i,v_raw_i,n_o,n_raw,v_missing,v_raw_missing,v_collisions,v_raw_collisions;
  END IF;
  RAISE NOTICE 'Carga validada: staging=% pacientes=% lesoes_pares=% imagens=% observacoes_fitz=% fitz_vazios=% ids_lesao_reutilizados=%',
    n_stg,n_p,n_l,n_i,n_o,v_missing,v_collisions;
END $$;
COMMIT;

-- Resultado materializado no artefato derm_v2, nao apenas uma tabela temporaria.
SELECT json_build_object(
    'fonte_id', f.fonte_id,
    'staging', (SELECT count(*) FROM derm_v2.staging_registro s WHERE s.fonte_id=f.fonte_id),
    'pacientes', (SELECT count(*) FROM derm_v2.paciente p WHERE p.fonte_id=f.fonte_id),
    'lesoes_com_identidade_composta', (SELECT count(*) FROM derm_v2.lesao l WHERE l.fonte_id=f.fonte_id),
    'imagens', (SELECT count(*) FROM derm_v2.imagem i WHERE i.fonte_id=f.fonte_id),
    'observacoes_fitzpatrick', (SELECT count(*) FROM derm_v2.observacao o WHERE o.fonte_id=f.fonte_id),
    'fitzpatrick_ausente', (SELECT count(*) FROM derm_v2.observacao o
        WHERE o.fonte_id=f.fonte_id AND o.atributo='fitzpatrick' AND o.estado='ausente'),
    'fitzpatrick_preenchido', (SELECT count(*) FROM derm_v2.observacao o
        WHERE o.fonte_id=f.fonte_id AND o.atributo='fitzpatrick' AND o.estado='preenchido'),
    'rejeicoes_vinculo', (SELECT count(*) FROM derm_v2.rejeicao_vinculo r WHERE r.fonte_id=f.fonte_id)
) AS resultado_json
FROM derm_v2.fonte f
WHERE f.nome = 'PAD-UFES-20 metadata.csv'
  AND f.versao = 'sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527';
