-- TESTE DE FUMACA SINTETICO PARA POSTGRESQL 16.
-- Pre-requisito: esquema_postgresql16_v2.sql instalado sem erros.
-- NAO executar em producao. ROLLBACK ao final, sem persistencia.
-- Resultados nao foram produzidos pelo autor deste arquivo.
BEGIN;
SET LOCAL search_path TO derm_v2, pg_catalog;

DO $$
DECLARE
    f1 bigint; f2 bigint;
    p1 bigint; p2 bigint; l1 bigint; i1 bigint; i2 bigint;
    m1 bigint; o1 bigint;
    erro_esperado boolean;
BEGIN
    INSERT INTO fonte(nome, versao, instituicao_fornecedora,
                      uf_instituicao_ibge, municipio_instituicao_ibge)
    VALUES ('FONTE_SINTETICA_A', 'v1', 'INSTITUICAO_FICTICIA', '23', '2304400')
    RETURNING fonte_id INTO f1;
    INSERT INTO fonte(nome, versao) VALUES ('FONTE_SINTETICA_B', 'v1')
    RETURNING fonte_id INTO f2;

    INSERT INTO catalogo_fonte_atributo(fonte_id, atributo, unidade,
                                       campo_existe, nome_campo_origem, tipo_dado_original)
    VALUES (f1, 'raca_cor_ibge', 'paciente', true, 'rotulo_teste_raca', 'text'),
           (f1, 'fitzpatrick', 'imagem', true, 'rotulo_teste_fitz', 'text'),
           (f2, 'monk', 'imagem', false, NULL, NULL);

    INSERT INTO paciente(fonte_id, identificador_origem,
                         uf_residencia_ibge, municipio_residencia_ibge)
    VALUES (f1, 'PACIENTE_TESTE_1', '24', NULL)
    RETURNING paciente_id INTO p1;
    INSERT INTO paciente(fonte_id, identificador_origem)
    VALUES (f2, 'PACIENTE_TESTE_2') RETURNING paciente_id INTO p2;

    INSERT INTO lesao(fonte_id, paciente_id,
                      evidencia_vinculo_paciente, identificador_origem)
    VALUES (f1, p1, 'Ligacao documentada no fixture sintetico', 'LESAO_TESTE_1')
    RETURNING lesao_id INTO l1;
    INSERT INTO imagem(fonte_id, lesao_id, evidencia_vinculo_lesao,
                       modalidade, identificador_origem)
    VALUES (f1, l1, 'Ligacao documentada no fixture sintetico',
            'clinica', 'IMAGEM_TESTE_1') RETURNING imagem_id INTO i1;
    INSERT INTO imagem(fonte_id, modalidade, identificador_origem)
    VALUES (f2, 'dermatoscopica', 'IMAGEM_TESTE_2')
    RETURNING imagem_id INTO i2;

    INSERT INTO mapeamento_valor (
        fonte_id, atributo, unidade, versao_mapeamento,
        valor_origem, estado_destino, valor_categoria_destino, regra_documentada
    ) VALUES (
        f1, 'raca_cor_ibge', 'paciente', 1,
        'Branca', 'preenchido', 'branca', 'Normalizar capitalizacao; fixture sintetico'
    ) RETURNING mapeamento_id INTO m1;

    INSERT INTO observacao (
        fonte_id, atributo, unidade, paciente_id, estado, valor_categoria,
        valor_origem, mapeamento_id, metodo, situacao_atribuidor
    ) VALUES (
        f1, 'raca_cor_ibge', 'paciente', p1, 'preenchido', 'branca',
        'Branca', m1, 'autodeclaracao', 'nao_documentado'
    ) RETURNING observacao_id INTO o1;

    -- Teste A: mapeamento diverge do valor original -> erro de CHECK (23514).
    erro_esperado := false;
    BEGIN
      INSERT INTO observacao(fonte_id, atributo, unidade, paciente_id,
                            estado, valor_categoria, valor_origem, mapeamento_id)
      VALUES (f1, 'raca_cor_ibge', 'paciente', p1,
              'preenchido', 'branca', 'Parda', m1);
    EXCEPTION WHEN check_violation THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'A: mapeamento divergente nao rejeitado'; END IF;

    -- Teste B: dominio de raca/cor invalido -> erro CHECK.
    erro_esperado := false;
    BEGIN
      INSERT INTO mapeamento_valor(fonte_id, atributo, unidade, versao_mapeamento,
              valor_origem, estado_destino, valor_categoria_destino, regra_documentada)
      VALUES (f1, 'raca_cor_ibge', 'paciente', 1, 'AZUL', 'preenchido', 'azul', 'fixture');
    EXCEPTION WHEN check_violation THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'B: dominio invalido nao rejeitado'; END IF;

    -- Teste C: associacao entre fontes diferentes -> FK rejeitada.
    erro_esperado := false;
    BEGIN
      INSERT INTO lesao(fonte_id, paciente_id, evidencia_vinculo_paciente)
      VALUES (f2, p1, 'tentativa sintetica');
    EXCEPTION WHEN foreign_key_violation THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'C: FK cruzada nao rejeitada'; END IF;

    -- Teste D: campo inexistente no catalogo nao aceita observacao.
    erro_esperado := false;
    BEGIN
      INSERT INTO observacao(fonte_id, atributo, unidade, imagem_id, estado)
      VALUES (f2, 'monk', 'imagem', i2, 'ausente');
    EXCEPTION WHEN check_violation THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'D: campo estruturalmente inexistente aceito'; END IF;

    -- Teste E: paciente E imagem na mesma observacao -> exclusividade rejeitada.
    erro_esperado := false;
    BEGIN
      INSERT INTO observacao(fonte_id, atributo, unidade, paciente_id,
              imagem_id, estado)
      VALUES (f1, 'raca_cor_ibge', 'paciente', p1, i1, 'ausente');
    EXCEPTION WHEN check_violation THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'E: XOR nao aplicado'; END IF;

    -- Teste F: raca/cor nao deve ser atribuida por algoritmo.
    erro_esperado := false;
    BEGIN
      INSERT INTO observacao(fonte_id, atributo, unidade, paciente_id, estado,
          valor_categoria, valor_origem, mapeamento_id, metodo)
      VALUES (f1, 'raca_cor_ibge', 'paciente', p1, 'preenchido',
              'branca', 'Branca', m1, 'atribuicao_algoritmica');
    EXCEPTION WHEN check_violation THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'F: raca algoritmica aceita'; END IF;

    -- Teste G: mapeamento nao deve ser editado.
    erro_esperado := false;
    BEGIN
      UPDATE mapeamento_valor SET regra_documentada = 'nova regra' WHERE mapeamento_id = m1;
    EXCEPTION WHEN object_not_in_prerequisite_state THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'G: mapeamento editavel'; END IF;

    -- Teste H: alternancia do catalogo com dado referenciado deve ser rejeitada.
    erro_esperado := false;
    BEGIN
      UPDATE catalogo_fonte_atributo
      SET campo_existe = false, nome_campo_origem = NULL, tipo_dado_original = NULL
      WHERE fonte_id = f1 AND atributo = 'raca_cor_ibge' AND unidade = 'paciente';
    EXCEPTION WHEN check_violation THEN erro_esperado := true;
    END;
    IF NOT erro_esperado THEN RAISE EXCEPTION 'H: catalogo foi desativado com dados'; END IF;

    RAISE NOTICE 'Fixtures sinteticos: testes A-H passaram nesta transacao (sera revertida).';
END;
$$;
ROLLBACK;
