-- Teste negativo: mesmamente paciente+lesion_id nao pode ter duas linhas; outro paciente pode.
-- Sintetico: ROLLBACK ao final, dados reais preservados.
BEGIN;
DO $$
DECLARE
    fonte bigint;
    p_a bigint;
    p_b bigint;
    ok boolean := false;
BEGIN
  SELECT fonte_id INTO STRICT fonte FROM derm_v2.fonte
  WHERE nome='PAD-UFES-20 metadata.csv'
    AND versao='sha256:14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527';
  SELECT paciente_id INTO STRICT p_a FROM derm_v2.paciente WHERE fonte_id=fonte ORDER BY paciente_id LIMIT 1;
  SELECT paciente_id INTO STRICT p_b FROM derm_v2.paciente WHERE fonte_id=fonte AND paciente_id<>p_a ORDER BY paciente_id LIMIT 1;
  INSERT INTO derm_v2.lesao(fonte_id,paciente_id,evidencia_vinculo_paciente,identificador_origem)
  VALUES (fonte,p_a,'TESTE_SINTETICO_ROLLBACK','__ID_TESTE_NAO_PUBLICADO__');
  INSERT INTO derm_v2.lesao(fonte_id,paciente_id,evidencia_vinculo_paciente,identificador_origem)
  VALUES (fonte,p_b,'TESTE_SINTETICO_ROLLBACK','__ID_TESTE_NAO_PUBLICADO__');
  BEGIN
    INSERT INTO derm_v2.lesao(fonte_id,paciente_id,evidencia_vinculo_paciente,identificador_origem)
    VALUES (fonte,p_a,'TESTE_SINTETICO_ROLLBACK','__ID_TESTE_NAO_PUBLICADO__');
  EXCEPTION WHEN unique_violation THEN
    ok := true;
  END;
  IF NOT ok THEN
    RAISE EXCEPTION 'FALHA: duplicata no mesmo paciente foi aceita';
  END IF;
  RAISE NOTICE 'PASSOU: mesmo lesion_id pode coexistir entre dois pacientes e duplicata por paciente foi rejeitada';
END $$;
ROLLBACK;
