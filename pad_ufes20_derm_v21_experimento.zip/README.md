# Experimento PAD-UFES-20 — esquema derm_v2 revisado v2.1

**Dados fonte**: `metadata.csv` com SHA-256 `14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527`.

**Motivo da revisao**: 250 valores `lesion_id` apareciam com dois `patient_id` diferentes; original v2 possuia indice unico `(fonte_id, identificador_origem)` em `lesao`, incompatível com a fonte. No v2.1 usa-se `UNIQUE INDEX (fonte_id, paciente_id, identificador_origem) NULLS NOT DISTINCT`.

**Arquivos:**
- 01: DDL com correção contextual, restante do esquema v2 preservado.
- 02: ETL com staging das 26 colunas, 3 unidades distintas e 2298 observacoes de fitzpatrick por imagem, incluindo vazios e mapeamentos versionados.
- 03: teste de indice em transação `ROLLBACK`, sem deixar dados sintéticos.
- 04: oito testes negativos (A-H) de restrições da especificação, com `ROLLBACK`.

**Como executar:** usar Google Colab e upload do ZIP, com PostgreSQL 16 iniciado. O codigo da conversa verifica SHA e executa 01, 02 e 03 no mesmo banco `postgres`. **Nao executar arquivos 01/02 duas vezes**; sao scripts de carga inicial deliberadamente nao idempotentes e nao contem DROP/limpeza silenciosa.

**Limites das evidencias:**
- `registro_jsonb` e copia textual estruturada das 26 colunas da linha, nao byte a byte; o hash original preservado no relatorio e nome da versao permite auditoria de reproducibilidade.
- `paciente_id` e `lesion_id` sao identificadores de origem e **nao** entidades clinicas auditadas. O par foi usado como chave documentada no CSV.
- Para fitspatrick, a unidade adotada e `imagem`, que corresponde ao grao do registro `img_id`; nao se infere atribuicao, autodeclaracao ou consistencia por paciente.
- O arquivo nao contem `raca_cor_ibge` e nenhum valor e inferido.
- O mapeamento explicito de string vazia `''` para estado `ausente` segue regra do experimento; `UNK` nao foi equiparado a vazio.
- `verificacao_objeto` continua vazia; nada foi verificado no MinIO/S3 e nao houve carga dos binarios de imagem.
- O teste negativo de indice usa fixture artificial dentro de transacao revertida e nao altera dados reais.
- Essa ingestao nao declara aprovacão de Q1–Q8: apenas verifica importacao, preservacao de staging, integridade basica e fototipo por imagem.
