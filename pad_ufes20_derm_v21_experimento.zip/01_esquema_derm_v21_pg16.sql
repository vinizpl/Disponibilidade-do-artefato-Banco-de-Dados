-- Esquema dermatologico v2.1 (Design Science Research)
-- Revisao experimental: colisao dos identificadores de lesao entre pacientes observada
-- em PAD-UFES-20 metadata.csv, SHA256 14d145235cedb022548257acb0d84dcd949e2c916f65d2baa7c38ed5339e9527.
-- ALVO: PostgreSQL 16.x; PL/pgSQL nativo, sem extensoes externas.
-- EXECUCAO: psql -X -v ON_ERROR_STOP=1 -d SEU_BANCO -f esquema_postgresql16_v2.sql
-- Executar UMA VEZ em banco no qual o schema derm_v2 ainda nao existe.
-- NAO contem dados de pacientes, resultados experimentais ou termos diagnosticos presumidos.
-- O registro da fonte corresponde a UMA versao de cada colecao.

BEGIN;
CREATE SCHEMA derm_v2;
SET LOCAL search_path TO derm_v2, pg_catalog;

-- Valores enumerados representam decisoes deste artefato, NAO terminologias oficiais completas.
CREATE TYPE tipo_atributo AS ENUM ('raca_cor_ibge', 'fitzpatrick', 'ita', 'monk');
CREATE TYPE unidade_observacao AS ENUM ('paciente', 'imagem');
CREATE TYPE estado_observacao AS ENUM ('preenchido', 'ausente', 'desconhecido', 'nao_aplicavel');
CREATE TYPE metodo_atribuicao AS ENUM (
    'autodeclaracao', 'declaracao_responsavel', 'registro_profissional',
    'avaliacao_dermatologista', 'avaliacao_leigo_treinado', 'medicao_instrumental',
    'atribuicao_algoritmica', 'outro_documentado', 'nao_documentado'
);
CREATE TYPE tipo_agente AS ENUM (
    'participante', 'responsavel', 'dermatologista', 'profissional_saude',
    'avaliador_treinado', 'sistema', 'outro'
);
CREATE TYPE estado_atribuidor AS ENUM ('identificado', 'nao_documentado');
CREATE TYPE modalidade_imagem AS ENUM ('clinica', 'dermatoscopica');
CREATE TYPE tipo_confirmacao AS ENUM ('histopatologia', 'consenso', 'seguimento');
CREATE TYPE classificacao_diagnostica AS ENUM ('benigno', 'maligno', 'indeterminado');
CREATE TYPE estado_verificacao_objeto AS ENUM (
    'presente', 'nao_encontrado', 'hash_divergente', 'inacessivel'
);
CREATE TYPE tipo_vinculo_rejeitado AS ENUM (
    'lesao_paciente', 'imagem_lesao', 'diagnostico_alvo', 'observacao_sujeito'
);
CREATE TYPE motivo_vinculo_rejeitado AS ENUM (
    'identificador_inexistente', 'fonte_incompativel', 'sem_evidencia',
    'formato_invalido', 'outro'
);

-- Formato e coerencia de prefixo. Nao valida existencia do municipio em tabela IBGE.
CREATE DOMAIN codigo_uf_ibge AS text
    CHECK (VALUE IS NULL OR VALUE ~
       '^(11|12|13|14|15|16|17|21|22|23|24|25|26|27|28|29|31|32|33|35|41|42|43|50|51|52|53)$');
CREATE DOMAIN codigo_municipio_ibge AS text
    CHECK (VALUE IS NULL OR VALUE ~ '^[0-9]{7}$');

-- 1. Fonte versionada e local da INSTITUICAO (nao da residencia do paciente).
CREATE TABLE fonte (
    fonte_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome text NOT NULL CHECK (btrim(nome) <> ''),
    versao text NOT NULL CHECK (btrim(versao) <> ''),
    instituicao_fornecedora text,
    uf_instituicao_ibge codigo_uf_ibge,
    municipio_instituicao_ibge codigo_municipio_ibge,
    url_documentacao text,
    data_acesso date,
    criada_em timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_fonte_nome_versao UNIQUE (nome, versao),
    CONSTRAINT ck_fonte_municipio_uf CHECK (
        municipio_instituicao_ibge IS NULL OR uf_instituicao_ibge IS NULL
        OR left(municipio_instituicao_ibge, 2) = uf_instituicao_ibge
    )
);

-- 2. Catalogo estruturado por (fonte, atributo, unidade).
-- A ausencia ESTRUTURAL e armazenada aqui, nunca em estado_observacao.
CREATE TABLE catalogo_fonte_atributo (
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    atributo tipo_atributo NOT NULL,
    unidade unidade_observacao NOT NULL,
    campo_existe boolean NOT NULL,
    nome_campo_origem text,
    definicao_original text,
    tipo_dado_original text,
    evidencia_documental text,
    PRIMARY KEY (fonte_id, atributo, unidade),
    CONSTRAINT ck_catalogo_campo_ausente CHECK (
        campo_existe OR (
            nome_campo_origem IS NULL AND definicao_original IS NULL
            AND tipo_dado_original IS NULL
        )
    ),
    CONSTRAINT ck_catalogo_nome_campo CHECK (
        nome_campo_origem IS NULL OR btrim(nome_campo_origem) <> ''
    )
);

-- 3. Staging: copia estruturada do registro fornecido.
-- JSONB NAO conserva ordem de chaves, espacos ou chaves duplicadas do JSON textual.
CREATE TABLE staging_registro (
    staging_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    identificador_registro_origem text,
    colecao_ou_arquivo_origem text,
    registro_jsonb jsonb NOT NULL,
    recebido_em timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_staging_objeto CHECK (jsonb_typeof(registro_jsonb) = 'object'),
    CONSTRAINT uq_staging_id_fonte UNIQUE (staging_id, fonte_id)
);

-- 4. Unidades observacionais, preservadas separadamente.
CREATE TABLE paciente (
    paciente_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    identificador_origem text,
    staging_id bigint,
    uf_residencia_ibge codigo_uf_ibge,
    municipio_residencia_ibge codigo_municipio_ibge,
    CONSTRAINT uq_paciente_id_fonte UNIQUE (paciente_id, fonte_id),
    CONSTRAINT fk_paciente_staging FOREIGN KEY (staging_id, fonte_id)
        REFERENCES staging_registro (staging_id, fonte_id),
    CONSTRAINT ck_paciente_residencia CHECK (
        municipio_residencia_ibge IS NULL OR uf_residencia_ibge IS NULL
        OR left(municipio_residencia_ibge, 2) = uf_residencia_ibge
    ),
    CONSTRAINT ck_paciente_identificador CHECK (
        identificador_origem IS NULL OR btrim(identificador_origem) <> ''
    )
);

CREATE TABLE lesao (
    lesao_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    paciente_id bigint,                  -- opcional: NUNCA inferir
    evidencia_vinculo_paciente text,     -- campo/registro de origem que sustenta a associacao
    identificador_origem text,
    local_anatomico_original text,
    staging_id bigint,
    CONSTRAINT uq_lesao_id_fonte UNIQUE (lesao_id, fonte_id),
    CONSTRAINT fk_lesao_paciente FOREIGN KEY (paciente_id, fonte_id)
        REFERENCES paciente (paciente_id, fonte_id),
    CONSTRAINT fk_lesao_staging FOREIGN KEY (staging_id, fonte_id)
        REFERENCES staging_registro (staging_id, fonte_id),
    CONSTRAINT ck_lesao_evidencia_vinculo CHECK (
        (paciente_id IS NULL AND evidencia_vinculo_paciente IS NULL)
        OR (paciente_id IS NOT NULL AND evidencia_vinculo_paciente IS NOT NULL
            AND btrim(evidencia_vinculo_paciente) <> '')
    ),
    CONSTRAINT ck_lesao_identificador CHECK (
        identificador_origem IS NULL OR btrim(identificador_origem) <> ''
    )
);

CREATE TABLE imagem (
    imagem_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    lesao_id bigint,                     -- opcional: NUNCA inferir
    evidencia_vinculo_lesao text,        -- campo/registro de origem que sustenta a associacao
    identificador_origem text,
    modalidade modalidade_imagem,        -- NULL = modalidade nao documentada
    dispositivo_original text,
    data_aquisicao date,
    bucket text,
    chave_objeto text,
    tamanho_bytes bigint,
    sha256_hex text,
    uri_externa text,
    staging_id bigint,
    CONSTRAINT uq_imagem_id_fonte UNIQUE (imagem_id, fonte_id),
    CONSTRAINT fk_imagem_lesao FOREIGN KEY (lesao_id, fonte_id)
        REFERENCES lesao (lesao_id, fonte_id),
    CONSTRAINT fk_imagem_staging FOREIGN KEY (staging_id, fonte_id)
        REFERENCES staging_registro (staging_id, fonte_id),
    CONSTRAINT ck_imagem_evidencia_vinculo CHECK (
        (lesao_id IS NULL AND evidencia_vinculo_lesao IS NULL)
        OR (lesao_id IS NOT NULL AND evidencia_vinculo_lesao IS NOT NULL
            AND btrim(evidencia_vinculo_lesao) <> '')
    ),
    CONSTRAINT ck_imagem_bucket_chave CHECK (
        (bucket IS NULL AND chave_objeto IS NULL)
        OR (bucket IS NOT NULL AND chave_objeto IS NOT NULL
            AND btrim(bucket) <> '' AND btrim(chave_objeto) <> '')
    ),
    CONSTRAINT ck_imagem_sha256 CHECK (
        sha256_hex IS NULL OR sha256_hex ~ '^[0-9a-f]{64}$'
    ),
    CONSTRAINT ck_imagem_tamanho CHECK (tamanho_bytes IS NULL OR tamanho_bytes >= 0),
    CONSTRAINT ck_imagem_uri CHECK (uri_externa IS NULL OR btrim(uri_externa) <> ''),
    CONSTRAINT ck_imagem_identificador CHECK (
        identificador_origem IS NULL OR btrim(identificador_origem) <> ''
    )
);

-- 5. Agente pseudonimizado ou papel identificado; nao pressupoem nome real.
CREATE TABLE agente_atribuicao (
    agente_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    tipo tipo_agente NOT NULL,
    codigo_pseudonimo text,
    descricao_papel text,
    CONSTRAINT uq_agente_id_fonte UNIQUE (agente_id, fonte_id),
    CONSTRAINT ck_agente_codigo CHECK (
        codigo_pseudonimo IS NULL OR btrim(codigo_pseudonimo) <> ''
    )
);

-- 6. Vocabulario diagnostico controlado: NAO pre-populado com termos inventados.
CREATE TABLE vocabulario_diagnostico (
    sistema text NOT NULL CHECK (btrim(sistema) <> ''),
    versao text NOT NULL CHECK (btrim(versao) <> ''),
    codigo text NOT NULL CHECK (btrim(codigo) <> ''),
    rotulo text NOT NULL CHECK (btrim(rotulo) <> ''),
    classificacao classificacao_diagnostica NOT NULL,
    referencia_vocabulario text,
    PRIMARY KEY (sistema, versao, codigo)
);

-- Diagnostico aponta para lesao OU imagem; permite colecoes sem identificador de lesao.
CREATE TABLE diagnostico (
    diagnostico_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    lesao_id bigint,
    imagem_id bigint,
    sistema_vocabulario text NOT NULL,
    versao_vocabulario text NOT NULL,
    codigo_diagnostico text NOT NULL,
    tipo_confirmacao tipo_confirmacao,
    data_diagnostico date,
    data_confirmacao date,
    staging_id bigint,
    CONSTRAINT uq_diagnostico_id_fonte UNIQUE (diagnostico_id, fonte_id),
    CONSTRAINT ck_diagnostico_sujeito_xor CHECK (
        (lesao_id IS NOT NULL AND imagem_id IS NULL)
        OR (imagem_id IS NOT NULL AND lesao_id IS NULL)
    ),
    CONSTRAINT fk_diagnostico_lesao FOREIGN KEY (lesao_id, fonte_id)
        REFERENCES lesao (lesao_id, fonte_id),
    CONSTRAINT fk_diagnostico_imagem FOREIGN KEY (imagem_id, fonte_id)
        REFERENCES imagem (imagem_id, fonte_id),
    CONSTRAINT fk_diagnostico_vocabulario FOREIGN KEY
        (sistema_vocabulario, versao_vocabulario, codigo_diagnostico)
        REFERENCES vocabulario_diagnostico (sistema, versao, codigo),
    CONSTRAINT fk_diagnostico_staging FOREIGN KEY (staging_id, fonte_id)
        REFERENCES staging_registro (staging_id, fonte_id)
);

-- 7. Mapeamento por valor, versionado e posteriormente IMUTAVEL.
-- Exemplo de regra (SEM insercao de dados): valor original -> estado/codigo canonico.
CREATE TABLE mapeamento_valor (
    mapeamento_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    atributo tipo_atributo NOT NULL,
    unidade unidade_observacao NOT NULL,
    versao_mapeamento integer NOT NULL CHECK (versao_mapeamento > 0),
    valor_origem text NOT NULL,          -- inclui eventualmente string vazia da fonte
    estado_destino estado_observacao NOT NULL,
    valor_categoria_destino text,
    valor_numerico_destino numeric(8,3),
    regra_documentada text NOT NULL CHECK (btrim(regra_documentada) <> ''),
    agente_responsavel_id bigint,
    criado_em timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_mapeamento_id_fonte_atributo_unidade UNIQUE
        (mapeamento_id, fonte_id, atributo, unidade),
    CONSTRAINT uq_mapeamento_versao_valor UNIQUE
        (fonte_id, atributo, unidade, versao_mapeamento, valor_origem),
    CONSTRAINT fk_mapeamento_catalogo FOREIGN KEY (fonte_id, atributo, unidade)
        REFERENCES catalogo_fonte_atributo (fonte_id, atributo, unidade),
    CONSTRAINT fk_mapeamento_agente FOREIGN KEY (agente_responsavel_id, fonte_id)
        REFERENCES agente_atribuicao (agente_id, fonte_id),
    CONSTRAINT ck_mapeamento_ausencia CHECK (
        (estado_destino <> 'preenchido'
            AND valor_categoria_destino IS NULL AND valor_numerico_destino IS NULL)
        OR estado_destino = 'preenchido'
    ),
    CONSTRAINT ck_mapeamento_dominio CHECK (
        estado_destino <> 'preenchido'
        OR CASE atributo
            WHEN 'raca_cor_ibge' THEN
                valor_categoria_destino IS NOT NULL
                AND valor_categoria_destino IN ('branca','preta','amarela','parda','indigena')
                AND valor_numerico_destino IS NULL
            WHEN 'fitzpatrick' THEN
                valor_categoria_destino IS NOT NULL
                AND valor_categoria_destino IN ('I','II','III','IV','V','VI')
                AND valor_numerico_destino IS NULL
            WHEN 'monk' THEN
                valor_categoria_destino IS NOT NULL
                AND valor_categoria_destino IN ('1','2','3','4','5','6','7','8','9','10')
                AND valor_numerico_destino IS NULL
            WHEN 'ita' THEN
                valor_categoria_destino IS NULL
                AND valor_numerico_destino IS NOT NULL
                AND valor_numerico_destino BETWEEN -90 AND 90
        END
    )
);

-- 8. Mesmo padrao sujeito-atributo-valor-metodo-agente-data-fonte para 4 atributos.
-- OBS: nao existe unidade 'lesao' nesta tabela por especificacao da Etapa 3.
CREATE TABLE observacao (
    observacao_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    atributo tipo_atributo NOT NULL,
    unidade unidade_observacao NOT NULL,
    paciente_id bigint,
    imagem_id bigint,
    estado estado_observacao NOT NULL,
    valor_categoria text,
    valor_numerico numeric(8,3),
    valor_origem text,
    mapeamento_id bigint,
    metodo metodo_atribuicao NOT NULL DEFAULT 'nao_documentado',
    agente_id bigint,
    situacao_atribuidor estado_atribuidor NOT NULL DEFAULT 'nao_documentado',
    data_atribuicao date,
    staging_id bigint,
    registrada_em timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_observacao_id_fonte UNIQUE (observacao_id, fonte_id),
    CONSTRAINT ck_observacao_sujeito_xor CHECK (
        (unidade = 'paciente' AND paciente_id IS NOT NULL AND imagem_id IS NULL)
        OR (unidade = 'imagem' AND imagem_id IS NOT NULL AND paciente_id IS NULL)
    ),
    CONSTRAINT ck_observacao_metodo_raca CHECK (
        atributo <> 'raca_cor_ibge' OR metodo IN
        ('autodeclaracao', 'declaracao_responsavel',
         'registro_profissional', 'nao_documentado')
    ),
    CONSTRAINT ck_observacao_agente CHECK (
        (situacao_atribuidor = 'identificado' AND agente_id IS NOT NULL)
        OR (situacao_atribuidor = 'nao_documentado' AND agente_id IS NULL)
    ),
    CONSTRAINT ck_observacao_valor_origem_mapeado CHECK (
        (estado = 'preenchido' AND valor_origem IS NOT NULL
         AND btrim(valor_origem) <> '' AND mapeamento_id IS NOT NULL)
        OR (estado <> 'preenchido' AND
            (valor_origem IS NULL OR mapeamento_id IS NOT NULL))
    ),
    CONSTRAINT ck_observacao_ausencia CHECK (
        (estado <> 'preenchido'
            AND valor_categoria IS NULL AND valor_numerico IS NULL)
        OR estado = 'preenchido'
    ),
    CONSTRAINT ck_observacao_dominio CHECK (
        estado <> 'preenchido'
        OR CASE atributo
            WHEN 'raca_cor_ibge' THEN
                valor_categoria IS NOT NULL
                AND valor_categoria IN ('branca','preta','amarela','parda','indigena')
                AND valor_numerico IS NULL
            WHEN 'fitzpatrick' THEN
                valor_categoria IS NOT NULL
                AND valor_categoria IN ('I','II','III','IV','V','VI')
                AND valor_numerico IS NULL
            WHEN 'monk' THEN
                valor_categoria IS NOT NULL
                AND valor_categoria IN ('1','2','3','4','5','6','7','8','9','10')
                AND valor_numerico IS NULL
            WHEN 'ita' THEN
                valor_categoria IS NULL
                AND valor_numerico IS NOT NULL
                AND valor_numerico BETWEEN -90 AND 90
        END
    ),
    CONSTRAINT fk_observacao_catalogo FOREIGN KEY (fonte_id, atributo, unidade)
        REFERENCES catalogo_fonte_atributo (fonte_id, atributo, unidade),
    CONSTRAINT fk_observacao_paciente FOREIGN KEY (paciente_id, fonte_id)
        REFERENCES paciente (paciente_id, fonte_id),
    CONSTRAINT fk_observacao_imagem FOREIGN KEY (imagem_id, fonte_id)
        REFERENCES imagem (imagem_id, fonte_id),
    CONSTRAINT fk_observacao_agente FOREIGN KEY (agente_id, fonte_id)
        REFERENCES agente_atribuicao (agente_id, fonte_id),
    CONSTRAINT fk_observacao_mapeamento FOREIGN KEY
        (mapeamento_id, fonte_id, atributo, unidade)
        REFERENCES mapeamento_valor (mapeamento_id, fonte_id, atributo, unidade),
    CONSTRAINT fk_observacao_staging FOREIGN KEY (staging_id, fonte_id)
        REFERENCES staging_registro (staging_id, fonte_id)
);

-- 9. Registro de verificacao: cada linha deve corresponder a uma tentativa REAL.
-- Nenhum estado operacional e atribuido sem checar o servico de objetos.
CREATE TABLE verificacao_objeto (
    verificacao_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    imagem_id bigint NOT NULL,
    verificada_em timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado estado_verificacao_objeto NOT NULL,
    tamanho_observado bigint,
    sha256_observado text,
    detalhe text,
    CONSTRAINT fk_verificacao_imagem FOREIGN KEY (imagem_id, fonte_id)
        REFERENCES imagem (imagem_id, fonte_id),
    CONSTRAINT ck_verificacao_tamanho CHECK
        (tamanho_observado IS NULL OR tamanho_observado >= 0),
    CONSTRAINT ck_verificacao_sha CHECK
        (sha256_observado IS NULL OR sha256_observado ~ '^[0-9a-f]{64}$')
);

-- 10. Log operacional: aplicacao/ETL deve registrar rejeicao em transacao separada.
-- FK invalida nao cria automaticamente log quando a transacao falha.
CREATE TABLE rejeicao_vinculo (
    rejeicao_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fonte_id bigint NOT NULL REFERENCES fonte(fonte_id),
    staging_id bigint,
    tipo_vinculo tipo_vinculo_rejeitado NOT NULL,
    motivo motivo_vinculo_rejeitado NOT NULL,
    identificador_citado text,
    detalhe text,
    ocorrida_em timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rejeicao_staging FOREIGN KEY (staging_id, fonte_id)
        REFERENCES staging_registro (staging_id, fonte_id)
);

-- 11. Indices orientados a identificadores de origem, joins por fonte e consultas CQ.
CREATE UNIQUE INDEX ux_paciente_id_origem
    ON paciente(fonte_id, identificador_origem) WHERE identificador_origem IS NOT NULL;
-- v2.1: lesao_id externo e unico apenas dentro do par fonte/paciente.
-- NULLS NOT DISTINCT mantem unicidade conservadora quando nao ha paciente documentado.
CREATE UNIQUE INDEX ux_lesao_id_origem
    ON lesao(fonte_id, paciente_id, identificador_origem) NULLS NOT DISTINCT
    WHERE identificador_origem IS NOT NULL;
CREATE UNIQUE INDEX ux_imagem_id_origem
    ON imagem(fonte_id, identificador_origem) WHERE identificador_origem IS NOT NULL;
CREATE UNIQUE INDEX ux_agente_codigo
    ON agente_atribuicao(fonte_id, codigo_pseudonimo)
    WHERE codigo_pseudonimo IS NOT NULL;

CREATE INDEX ix_staging_fonte_recebida ON staging_registro(fonte_id, recebido_em);
CREATE INDEX ix_catalogo_disponibilidade
    ON catalogo_fonte_atributo(fonte_id, campo_existe, unidade, atributo);
CREATE INDEX ix_lesao_paciente ON lesao(fonte_id, paciente_id)
    WHERE paciente_id IS NOT NULL;
CREATE INDEX ix_imagem_lesao ON imagem(fonte_id, lesao_id)
    WHERE lesao_id IS NOT NULL;
CREATE INDEX ix_diagnostico_lesao ON diagnostico(fonte_id, lesao_id)
    WHERE lesao_id IS NOT NULL;
CREATE INDEX ix_diagnostico_imagem ON diagnostico(fonte_id, imagem_id)
    WHERE imagem_id IS NOT NULL;
CREATE INDEX ix_diagnostico_vocabulario
    ON diagnostico(sistema_vocabulario, versao_vocabulario, codigo_diagnostico);
CREATE INDEX ix_obs_paciente_atributo_estado
    ON observacao(fonte_id, paciente_id, atributo, estado)
    WHERE paciente_id IS NOT NULL;
CREATE INDEX ix_obs_imagem_atributo_estado
    ON observacao(fonte_id, imagem_id, atributo, estado)
    WHERE imagem_id IS NOT NULL;
CREATE INDEX ix_obs_fonte_atributo_estado
    ON observacao(fonte_id, atributo, unidade, estado);
CREATE INDEX ix_obs_agente ON observacao(fonte_id, agente_id)
    WHERE agente_id IS NOT NULL;
CREATE INDEX ix_obs_mapeamento ON observacao(mapeamento_id)
    WHERE mapeamento_id IS NOT NULL;
CREATE INDEX ix_verificacao_imagem_recente
    ON verificacao_objeto(fonte_id, imagem_id, verificada_em DESC);
CREATE INDEX ix_rejeicao_fonte_motivo
    ON rejeicao_vinculo(fonte_id, motivo, ocorrida_em);

-- 12. CHECKs sao por linha; a regra de campo existente envolve outra tabela.
-- Esta verificacao com trava impede inserir mapeamento/observacao em catalogo falso.
CREATE FUNCTION fn_requer_campo_existente() RETURNS trigger
LANGUAGE plpgsql SET search_path = derm_v2, pg_catalog AS $$
DECLARE v_existe boolean;
BEGIN
    SELECT c.campo_existe INTO v_existe
    FROM catalogo_fonte_atributo AS c
    WHERE c.fonte_id = NEW.fonte_id
      AND c.atributo = NEW.atributo
      AND c.unidade = NEW.unidade
    FOR SHARE;
    IF v_existe IS DISTINCT FROM TRUE THEN
        RAISE EXCEPTION 'Atributo % / unidade % ausente no catalogo da fonte %',
            NEW.atributo, NEW.unidade, NEW.fonte_id
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_mapeamento_campo_existente
    BEFORE INSERT OR UPDATE OF fonte_id, atributo, unidade
    ON mapeamento_valor FOR EACH ROW
    EXECUTE FUNCTION fn_requer_campo_existente();
CREATE TRIGGER trg_observacao_campo_existente
    BEFORE INSERT OR UPDATE OF fonte_id, atributo, unidade
    ON observacao FOR EACH ROW
    EXECUTE FUNCTION fn_requer_campo_existente();

CREATE FUNCTION fn_proibe_remover_campo_com_dados() RETURNS trigger
LANGUAGE plpgsql SET search_path = derm_v2, pg_catalog AS $$
BEGIN
    IF OLD.campo_existe = TRUE AND NEW.campo_existe = FALSE THEN
        IF EXISTS (
            SELECT 1 FROM observacao o
            WHERE o.fonte_id = OLD.fonte_id AND o.atributo = OLD.atributo
              AND o.unidade = OLD.unidade
        ) OR EXISTS (
            SELECT 1 FROM mapeamento_valor m
            WHERE m.fonte_id = OLD.fonte_id AND m.atributo = OLD.atributo
              AND m.unidade = OLD.unidade
        ) THEN
            RAISE EXCEPTION 'Nao desativar campo com observacoes ou mapeamentos'
                USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_catalogo_proteger_dados
    BEFORE UPDATE OF campo_existe ON catalogo_fonte_atributo
    FOR EACH ROW EXECUTE FUNCTION fn_proibe_remover_campo_com_dados();

-- Cada observacao com mapeamento deve repetir EXATAMENTE origem e destino daquela regra.
CREATE FUNCTION fn_confere_mapeamento_observacao() RETURNS trigger
LANGUAGE plpgsql SET search_path = derm_v2, pg_catalog AS $$
DECLARE m record;
BEGIN
    IF NEW.mapeamento_id IS NULL THEN
        RETURN NEW;
    END IF;
    SELECT mv.valor_origem, mv.estado_destino, mv.valor_categoria_destino,
           mv.valor_numerico_destino INTO m
    FROM mapeamento_valor mv
    WHERE mv.mapeamento_id = NEW.mapeamento_id
      AND mv.fonte_id = NEW.fonte_id
      AND mv.atributo = NEW.atributo
      AND mv.unidade = NEW.unidade
    FOR SHARE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Mapeamento nao encontrado para observacao'
            USING ERRCODE = '23503';
    END IF;
    IF NEW.valor_origem IS DISTINCT FROM m.valor_origem
       OR NEW.estado IS DISTINCT FROM m.estado_destino
       OR NEW.valor_categoria IS DISTINCT FROM m.valor_categoria_destino
       OR NEW.valor_numerico IS DISTINCT FROM m.valor_numerico_destino THEN
        RAISE EXCEPTION 'Observacao diverge do mapeamento de valor/versionamento'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_observacao_valida_mapeamento
    BEFORE INSERT OR UPDATE OF mapeamento_id, valor_origem,
        estado, valor_categoria, valor_numerico, atributo, fonte_id, unidade
    ON observacao FOR EACH ROW
    EXECUTE FUNCTION fn_confere_mapeamento_observacao();

-- Regras anteriores permanecem documentadas; correcao exige nova versao/linha.
CREATE FUNCTION fn_mapeamento_somente_insercao() RETURNS trigger
LANGUAGE plpgsql SET search_path = derm_v2, pg_catalog AS $$
BEGIN
    RAISE EXCEPTION 'Mapeamentos sao imutaveis; insira nova versao'
        USING ERRCODE = '55000';
END;
$$;
CREATE TRIGGER trg_mapeamento_imutavel
    BEFORE UPDATE OR DELETE ON mapeamento_valor FOR EACH ROW
    EXECUTE FUNCTION fn_mapeamento_somente_insercao();

COMMENT ON SCHEMA derm_v2 IS
'Projeto v2. Observacoes por paciente ou imagem. Lesao mantida como unidade distinta.';
COMMENT ON COLUMN catalogo_fonte_atributo.campo_existe IS
'Inexistencia estrutural da fonte/versionamento; NAO e estado de observacao.';
COMMENT ON COLUMN observacao.estado IS
'Apenas preenchido/ausente/desconhecido/nao_aplicavel; nunca campo_inexistente.';
COMMENT ON COLUMN observacao.valor_origem IS
'Valor original textual. Quando informado, exige mapeamento versionado.';
COMMENT ON COLUMN fonte.municipio_instituicao_ibge IS
'Local da instituicao fornecedora, separado da residencia de paciente.';
COMMENT ON COLUMN paciente.municipio_residencia_ibge IS
'Residencia documentada; nao inferida da instituicao fornecedora.';

COMMIT;
